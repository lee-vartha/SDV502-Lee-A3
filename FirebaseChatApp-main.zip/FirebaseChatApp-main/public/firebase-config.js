const firebaseConfig = {
    apiKey: "AIzaSyCFZWGODQjhaom1-dxoRcxQ5yKBez-45bg",
    authDomain: "new-web-bc905.firebaseapp.com",
    databaseURL: "https://new-web-bc905-default-rtdb.asia-southeast1.firebasedatabase.app",
    projectId: "new-web-bc905",
    storageBucket: "new-web-bc905.appspot.com",
    messagingSenderId: "432159954616",
    appId: "1:432159954616:web:1cefd2fbca166d8194464d",
    measurementId: "G-ZXBR5X6SEH"
  };

  // Initialize Firebase
firebase.initializeApp(firebaseConfig);